---
name: VAJRA Threat Architecture
colors:
  surface: '#0f131c'
  surface-dim: '#0f131c'
  surface-bright: '#353942'
  surface-container-lowest: '#0a0e16'
  surface-container-low: '#181c24'
  surface-container: '#1c2028'
  surface-container-high: '#262a33'
  surface-container-highest: '#31353e'
  on-surface: '#dfe2ee'
  on-surface-variant: '#c7c4d7'
  inverse-surface: '#dfe2ee'
  inverse-on-surface: '#2c3039'
  outline: '#908fa0'
  outline-variant: '#464554'
  surface-tint: '#c0c1ff'
  primary: '#c0c1ff'
  on-primary: '#1000a9'
  primary-container: '#8083ff'
  on-primary-container: '#0d0096'
  inverse-primary: '#494bd6'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb3ad'
  on-tertiary: '#68000a'
  tertiary-container: '#ff5451'
  on-tertiary-container: '#5c0008'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e1e0ff'
  primary-fixed-dim: '#c0c1ff'
  on-primary-fixed: '#07006c'
  on-primary-fixed-variant: '#2f2ebe'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffdad7'
  tertiary-fixed-dim: '#ffb3ad'
  on-tertiary-fixed: '#410004'
  on-tertiary-fixed-variant: '#930013'
  background: '#0f131c'
  on-background: '#dfe2ee'
  surface-variant: '#31353e'
typography:
  display-mono:
    fontFamily: JetBrains Mono
    fontSize: 20px
    fontWeight: '700'
    lineHeight: 24px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Public Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0em
  body-default:
    fontFamily: Public Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: 0em
  body-dense:
    fontFamily: Public Sans
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 15px
    letterSpacing: 0.01em
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0em
  data-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0em
  hex-inspector:
    fontFamily: JetBrains Mono
    fontSize: 10.5px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: 0.05em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.08em
  badge-indicator:
    fontFamily: JetBrains Mono
    fontSize: 9px
    fontWeight: '800'
    lineHeight: 10px
    letterSpacing: 0.06em
spacing:
  gutter: 0.5rem
  margin: 0.75rem
  space-xs: 0.125rem
  space-sm: 0.25rem
  space-md: 0.5rem
  space-lg: 0.75rem
  space-xl: 1rem
---

## Brand & Style

The design system establishes an uncompromising, mission-critical operational command-and-control surface built for tactical air-gapped monitoring, unidirectional data diodes, and continuous passive network threat analysis. The design language operates at the intersection of defense-grade telemetry infrastructure and high-throughput network engineering. 

The aesthetic is **Industrial High-Density Technical Flat**: sharp, information-dense, highly structured, and utilitarian. It deliberately eliminates consumer SaaS flourishes—there are no soft diffuse shadows, floating conversational chat bubbles, decorative illustrations, or arbitrary whitespace padding. Every pixel is allocated to real-time packet visibility, flow classification, hardware diode link integrity, and rapid triage under high-stress cognitive load.

The UI targets elite Tier 3 SOC operators, defensive network engineers, and signals intelligence analysts. It communicates immediate certainty, verifiable auditability, and zero ambiguity in hardware physical state (such as physical RX-only enforcement and optical tap saturation).

## Colors

The system relies on an ultra-low reflectance, true-black and slate foundation to prevent eye fatigue during 12-hour continuous monitoring shifts, while ensuring optical status indicators achieve absolute dynamic contrast.

### Palette Architecture

- **Canvas & Base Foundations:**
  - Void Canvas: `#0B0F17` (Deepest ground for active telemetry frames)
  - Workstation Canvas: `#111827` (Main app frame and split-view gutters)
  - Panel Surface: `#161F30` (Default tier-1 surface for log tables and hex dumps)
  - Elevated Inspector Surface: `#1E293B` (Flyouts, sticky column headers, inspector tabs)
  - Control Borders & Segment Dividers: `#2E3E5B` (Primary structural edge)
  - Subtle Grid Lines: `#1F293D` (Sub-grid and byte matrix delimiters)

### Strict Telemetry & Severity Tokens

Color is an operational signal; it is never used purely for decoration. Background fills for alert badges must remain low-light to preserve legibility for glowing text counters.

- **CRITICAL:** Text/Border `#EF4444`, Fill `#450A0A` (Active exploit payloads, diode back-channel leakage attempts, anomalous command bursts).
- **HIGH:** Text/Border `#F97316`, Fill `#431407` (Protocol boundary violations, unrecognized UDP tunneling, beaconing patterns).
- **MEDIUM:** Text/Border `#FBBF24`, Fill `#422006` (Asymmetric sequence irregularities, unknown port classifications).
- **LOW:** Text/Border `#38BDF8`, Fill `#082F49` (Expected administrative syncs, safe multicast noise).
- **INFORMATIONAL:** Text/Border `#94A3B8`, Fill `#1E293B` (Flow lifecycle metadata, normal session state transitions).
- **HEALTHY / LINK ACTIVE:** Text/Border `#10B981`, Fill `#064E3B` (Diode optical RX signal nominal, framing sync locked, zero drop counters).
- **AI/ML PASSIVE INFERENCE:** Text/Border `#6366F1`, Fill `#1E1B4B` (Synthetic rule match, statistical entropy divergence, behavioral scoring).

## Typography

The typography strategy leverages two strict engines: **JetBrains Mono** for raw network telemetry, addresses, packet bytes, offsets, hashes, and protocol specs; and **Public Sans** for structured metadata, UI controls, and multi-line descriptive forensic notes.

### Monospace Standards
- Tabular figures (`tnum`) and zero-slashing are active globally by default across monospace layers.
- Byte representations in packet payload views must always output two hexadecimal characters (`00` to `FF`) paired with rigid monospace character tracking to avoid horizontal drift when viewing raw data streams.
- Timestamps must render strictly in ISO-8601 extended UTC format (`YYYY-MM-DDTHH:MM:SS.ffffffZ`).
- Flow tuples follow `[SRC_IP]:[PORT] -> [DST_IP]:[PORT]` using strict glyph alignment.

## Layout & Spacing

The layout model is built on an ultra-compact 4px grid (`0.25rem`), prioritizing immediate situational awareness across multi-display SOC setups (typically 1440p and 4K command centers). 

### Layout Engine
- **Master Docking Architecture:** Full viewport height layout (`100vh`) with fixed-height sub-panes. Horizontal and vertical splitters allow operators to distribute screen real estate between real-time packet ring buffers, flow session logs, hardware diode meters, and hex dissection views.
- **Data Density Over Whitespace:** Gutters and column gaps remain anchored at `0.5rem` (8px). Cell padding in packet tables never exceeds 4px vertically. Scrolling is localized entirely to data containers; the parent document canvas never scrolls.
- **Breakpoint Rules:**
  - **Ultra-Wide / Multi-Head (>= 1920px):** 3-pane structural layout active: Left Navigation & Hardware Health Bar (240px fixed), Center Telemetry Matrix (fluid flex-grow), Right Inspector / Payload Hex Dump (480px fixed).
  - **Standard Desktop (1280px - 1919px):** Inspector defaults to collapsible right panel or lower split-drawer layout (50/50 vertical division).
  - **Tactical Field / Portable Unit (< 1280px):** Single active panel with strict tabbed switching between Telemetry, Diode Health, and Payload Hex View.

## Elevation & Depth

Visual hierarchy is enforced exclusively through **Tonal Layering** and **Crisp Borders**. Diffuse drop shadows are excluded from the design language to maintain clarity across low-refresh telemetry video walls and avoid rasterization latency.

- **Level 0 (Base Ingestion Surface):** `#0B0F17`. The root viewport.
- **Level 1 (Docked Structural Units):** `#161F30` framed with a 1px solid `#2E3E5B` border. All standard data tables, payload grids, and charts sit here.
- **Level 2 (Active Focus & Sticky Headers):** `#1E293B` framed with `#334155`. Used for frozen table headers, active packet rows, and pinned filtering bars.
- **Level 3 (Modal Overlays / Emergency Intercepts):** `#111827` surface with a high-contrast 1px border colored according to alert level (e.g., `#EF4444` for Critical anomalies, `#6366F1` for AI classification verification). Shadows at this level are strictly sharp, low-blur ambient dark envelopes: `0 4px 12px rgba(0, 0, 0, 0.8)`.

## Shapes

The design system enforces a **Zero-Radius (`0px`) Sharp Geometry**. 

In an operational, military-grade SOC environment, round corners waste render cycles and consume critical optical space at cell boundaries. All elements—including buttons, table cells, metric panels, severity badges, and dropdown menus—terminate in precise, unrounded right-angle corners. Status indicators are strictly square or rectangular pill-blocks with hard angles.

## Components

### Telemetry Tables & Packet Dissectors
- **Header Structure:** Height `24px`. Background `#1E293B`, bottom border 1px solid `#2E3E5B`. Text styled as `label-caps` in `#94A3B8`. Columns support persistent mono-width sorting glyphs and direct inline regex search fields.
- **Data Rows:** Height `22px`. Alternating zebra backgrounds (`#111827` / `#161F30`). Row selection is highlighted via a 2px vertical left indicator strip (using the severity color) and an inner fill of `#1E293B`.
- **Packet Byte Dissector (Hex View):** Triple-column grid: Offset (8 hex chars, `#64748B`), Payload (16 byte pairs separated into groups of 8 with a space gutter, `#F1F5F9`), and ASCII translation (`#38BDF8`). Monospace font scale strictly uses `hex-inspector`. Non-printable bytes render as dim dots (`.` in `#475569`).

### Telemetry Badges & Severity Chips
- Displayed with `0px` border-radius, 1px solid stroke matching the state foreground color, and background alpha of 20%.
- Format: `[CODE] [LABEL]` (e.g., `CRIT CVE-2024-XXXX`, `DIODE RX:ACTIVE`).
- Monospace font scale `badge-indicator` in full uppercase.

### Hardware & Link Indicators (Data Diode / Passive Tap)
- **Optical Link Status Block:** Persistent 20px height widget displaying physical unidirectional health:
  - `TX TERMINATION: VERIFIED GROUNDED` (Static neutral dark state `#1E293B` with text `#64748B` to prove physical impossibility of reverse traffic).
  - `RX OPTICAL POWER: -3.2 dBm` (Terminal Emerald `#10B981` pulsing at 1Hz on active frame capture).
  - `BUFFER HEADROOM: 98.4%` (Bar visualization with 1px discrete step segments).

### Action Controls & Input Fields
- **Command Buttons:** Height `26px`. Background `#1E293B`, border 1px solid `#2E3E5B`, text `Public Sans` 12px bold `#F1F5F9`. Hover transitions immediately to `#2E3E5B` background with no easing delay.
- **Filter / PCAP Syntax Inputs:** Height `24px`. Background `#0B0F17`, border 1px solid `#2E3E5B`, text `data-mono` `#F8FAFC`. Focus border shifts to AI/ML Cobalt `#6366F1` with an inner glow of 0px. Real-time syntax error state immediately switches the border to `#EF4444`.

### Metrics & Buffer Gauges
- Monolithic numerical readouts using `display-mono`. Labels placed directly above or inline with metrics using `label-caps`. 
- Frame drop rates and packet burst graphs render as dense SVG step-charts or block-character canvas meters, omitting soft gradient fills.